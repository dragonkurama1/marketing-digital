import { Button } from "@/components/ui/button"
import { ArrowRight } from "lucide-react"

export function Quote() {
  return (
    <section id="contact" className="relative py-20 px-4 md:px-8 overflow-hidden">
      <div className="absolute inset-0 -z-10">
        <div className="absolute top-0 right-0 w-96 h-96 bg-primary/30 rounded-full blur-3xl"></div>
        <div className="absolute bottom-0 left-0 w-96 h-96 bg-primary/20 rounded-full blur-3xl"></div>
      </div>

      <div className="max-w-3xl mx-auto text-center">
        <h2 className="text-4xl md:text-5xl font-bold mb-8 text-balance">Prêt à Transformer Votre Marque ?</h2>
        <p className="text-lg text-muted-foreground mb-12">
          Obtiens une consultation gratuite et découvre comment nous pouvons propulser votre entreprise vers le succès.
        </p>
        <Button size="lg" className="bg-primary hover:bg-primary/90 text-primary-foreground">
          Réserver une Consultation
          <ArrowRight className="ml-2 h-5 w-5" />
        </Button>
      </div>
    </section>
  )
}
