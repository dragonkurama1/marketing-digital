const projects = [
  {
    title: "Refonte Marque Luxury",
    category: "Branding",
    image: "/luxury-brand-design.jpg",
  },
  {
    title: "Plateforme E-Commerce",
    category: "Développement",
    image: "/ecommerce-website-homepage.png",
  },
  {
    title: "Campagne Marketing Digital",
    category: "Marketing",
    image: "/digital-marketing-campaign.png",
  },
  {
    title: "Application Mobile",
    category: "App Design",
    image: "/mobile-app-ui.png",
  },
  {
    title: "SEO Optimisation",
    category: "SEO",
    image: "/seo-optimization-analytics.jpg",
  },
  {
    title: "Brand Identity",
    category: "Design",
    image: "/brand-identity-guidelines.jpg",
  },
]

export function Portfolio() {
  return (
    <section id="portfolio" className="py-20 px-4 md:px-8">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-16">
          <span className="text-primary text-sm font-semibold tracking-widest uppercase">Nos Réalisations</span>
          <h2 className="text-4xl md:text-5xl font-bold mt-4 text-balance">Portfolio Prestigieux</h2>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {projects.map((project, index) => (
            <div key={index} className="group relative overflow-hidden rounded-lg aspect-video cursor-pointer">
              <img
                src={project.image || "/placeholder.svg"}
                alt={project.title}
                className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex flex-col justify-end p-6">
                <p className="text-primary text-sm font-semibold mb-2">{project.category}</p>
                <h3 className="text-white text-xl font-bold">{project.title}</h3>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
