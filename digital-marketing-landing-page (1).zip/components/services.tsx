import { Zap, Palette, TrendingUp, Code2 } from "lucide-react"

const services = [
  {
    icon: <Zap className="w-10 h-10" />,
    title: "Stratégie Digitale",
    description: "Analyse approfondie et positionnement stratégique pour dominer votre secteur.",
  },
  {
    icon: <Palette className="w-10 h-10" />,
    title: "Design & Création",
    description: "Identité visuelle premium et designs créatifs qui marquent les esprits.",
  },
  {
    icon: <TrendingUp className="w-10 h-10" />,
    title: "Croissance & Performance",
    description: "Optimisation SEO, SEM et stratégies pour multiplier vos résultats.",
  },
  {
    icon: <Code2 className="w-10 h-10" />,
    title: "Développement Web",
    description: "Platforms web haute performance et optimisées pour la conversion.",
  },
]

export function Services() {
  return (
    <section id="services" className="py-24 px-4 md:px-8 bg-background border-b border-border/50">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="text-center mb-20">
          <span className="text-primary text-sm font-bold tracking-widest uppercase">Nos Spécialités</span>
          <h2 className="text-5xl md:text-6xl font-bold mt-6 text-balance text-foreground">Services Haut de Gamme</h2>
          <p className="text-muted-foreground text-lg mt-6 max-w-2xl mx-auto">
            Nous offrons des solutions digitales complètes et intégrées pour votre succès.
          </p>
        </div>

        {/* Services Grid - Enhanced styling for luxury feel */}
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {services.map((service, index) => (
            <div
              key={index}
              className="group bg-secondary/40 border border-border/50 rounded-xl p-8 hover:border-primary/50 hover:bg-secondary/60 transition-all duration-500 hover:shadow-2xl hover:shadow-primary/10"
            >
              <div className="text-primary mb-6 group-hover:scale-125 group-hover:-rotate-12 transition-transform duration-500">
                {service.icon}
              </div>
              <h3 className="text-xl font-bold mb-4 text-foreground">{service.title}</h3>
              <p className="text-muted-foreground leading-relaxed text-sm group-hover:text-foreground/80 transition-colors">
                {service.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
