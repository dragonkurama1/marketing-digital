"use client"

import { useState } from "react"

interface IntroProps {
  onEnter: () => void
}

export function Intro({ onEnter }: IntroProps) {
  const [isDeploying, setIsDeploying] = useState(false)

  const handleClick = () => {
    setIsDeploying(true)
    setTimeout(() => {
      onEnter()
    }, 1200)
  }

  return (
    <div className="relative w-full h-screen bg-background overflow-hidden flex items-center justify-center">
      {/* Animated gradient backgrounds */}
      <div className="absolute inset-0">
        <div className="absolute top-0 left-1/2 transform -translate-x-1/2 w-96 h-96 bg-primary opacity-20 rounded-full filter blur-3xl animate-float" />
        <div
          className="absolute bottom-0 left-1/4 w-80 h-80 bg-primary opacity-10 rounded-full filter blur-3xl animate-float"
          style={{ animationDelay: "1s" }}
        />
        <div
          className="absolute top-1/2 right-0 w-96 h-96 bg-primary opacity-15 rounded-full filter blur-3xl animate-float"
          style={{ animationDelay: "2s" }}
        />
      </div>

      {/* Main content */}
      <div className="relative z-10 text-center px-4">
        {/* Title with entrance effect - Removed "scroll" text */}
        {!isDeploying && (
          <div className="transition-all duration-700 space-y-6">
            <h1 className="text-6xl md:text-8xl font-bold bg-gradient-to-r from-foreground via-primary to-foreground bg-clip-text text-transparent animate-woom">
              PRESTIGIA
            </h1>
            <p className="text-xl md:text-2xl text-muted-foreground animate-woom" style={{ animationDelay: "0.2s" }}>
              Découvrez nos services
            </p>
          </div>
        )}

        {/* Access button */}
        <button onClick={handleClick} disabled={isDeploying} className="relative group mt-12 overflow-hidden">
          <div
            className={`
            relative px-10 py-4 text-lg font-bold 
            border-2 border-primary text-foreground
            transition-all duration-300
            ${isDeploying ? "bg-primary text-primary-foreground" : "hover:bg-primary hover:text-primary-foreground"}
            rounded-lg
          `}
          >
            <span className="relative z-10">{isDeploying ? "Déploiement..." : "Accéder"}</span>
            <div
              className={`
              absolute inset-0 bg-primary transform origin-left
              transition-transform duration-700
              ${isDeploying ? "scale-x-100" : "scale-x-0"}
            `}
            />
          </div>
        </button>
      </div>

      {/* Circular deployment effect */}
      {isDeploying && (
        <div className="fixed inset-0 pointer-events-none">
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="w-32 h-32 rounded-full border-2 border-primary animate-ping opacity-75" />
            <div
              className="absolute w-64 h-64 rounded-full border border-primary opacity-50"
              style={{
                animation: "expandWoom 1s ease-out forwards",
              }}
            />
          </div>
        </div>
      )}

      <style jsx>{`
        @keyframes expandWoom {
          0% {
            width: 128px;
            height: 128px;
            opacity: 1;
          }
          100% {
            width: 1200px;
            height: 1200px;
            opacity: 0;
          }
        }
      `}</style>
    </div>
  )
}
