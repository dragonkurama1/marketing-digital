"use client"

import { MessageCircle } from "lucide-react"

export function WhatsAppButton() {
  const phoneNumber = "YOUR_WHATSAPP_NUMBER" // Replace with actual WhatsApp number (e.g., 212612345678)
  const message = "Bonjour, je souhaiterais en savoir plus sur vos services."
  const whatsappUrl = `https://wa.me/${phoneNumber}?text=${encodeURIComponent(message)}`

  return (
    <a href={whatsappUrl} target="_blank" rel="noopener noreferrer" className="fixed bottom-6 right-6 z-50 group">
      <div className="relative">
        <div className="absolute inset-0 bg-primary rounded-full blur-lg opacity-50 group-hover:opacity-75 transition-opacity duration-300" />

        <div className="relative w-14 h-14 bg-primary rounded-full flex items-center justify-center shadow-lg hover:shadow-2xl hover:shadow-primary/50 transition-all duration-300 hover:scale-110">
          <MessageCircle className="w-7 h-7 text-primary-foreground" />
        </div>
      </div>
    </a>
  )
}
