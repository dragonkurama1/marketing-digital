"use client"

export function Header() {
  const scrollToServices = () => {
    const element = document.getElementById("services")
    element?.scrollIntoView({ behavior: "smooth" })
  }

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: "smooth" })
  }

  return (
    <header className="fixed top-0 left-0 right-0 z-40 bg-background/80 backdrop-blur-lg border-b border-primary/20">
      <div className="max-w-7xl mx-auto px-4 md:px-8 py-4 flex items-center justify-between">
        <button
          onClick={scrollToTop}
          className="text-xl font-bold text-primary hover:text-primary/80 transition-colors duration-300 cursor-pointer"
        >
          PRESTIGIA
        </button>

        <nav className="hidden md:flex gap-12 items-center">
          <a
            href="#portfolio"
            className="text-sm text-muted-foreground hover:text-primary transition-colors duration-300 scroll-smooth"
          >
            Portfolio
          </a>
          <a
            href="#contact"
            className="text-sm text-muted-foreground hover:text-primary transition-colors duration-300 scroll-smooth"
          >
            Contact
          </a>
          <button
            onClick={scrollToServices}
            className="px-6 py-2 bg-primary text-primary-foreground text-sm font-semibold rounded-lg hover:bg-primary/90 transition-colors duration-300"
          >
            Explorer Services
          </button>
        </nav>
      </div>
    </header>
  )
}
