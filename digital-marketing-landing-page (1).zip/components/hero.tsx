"use client"

import { ArrowRight } from "lucide-react"
import { Button } from "@/components/ui/button"
import { useState } from "react"

export function Hero() {
  const [showQuote, setShowQuote] = useState(false)

  const scrollToServices = () => {
    const element = document.getElementById("services")
    element?.scrollIntoView({ behavior: "smooth" })
  }

  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden bg-background pt-20">
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute top-1/4 right-0 w-[500px] h-[500px] bg-primary/20 rounded-full blur-3xl animate-glow"></div>
        <div className="absolute bottom-0 left-1/4 w-[400px] h-[400px] bg-primary/10 rounded-full blur-3xl opacity-50"></div>
      </div>

      <div className="relative z-10 max-w-6xl mx-auto px-4 md:px-8">
        {/* Hero Content */}
        <div className="text-center space-y-8">
          <div className="animate-woom">
            <div className="mb-6 inline-block">
              <span className="text-primary text-sm font-bold tracking-widest uppercase">Agence Digitale Premium</span>
            </div>

            <h1 className="text-6xl md:text-8xl font-bold leading-tight text-balance text-foreground">
              Découvrez Nos Services
            </h1>

            <p className="text-lg md:text-xl text-muted-foreground max-w-3xl mx-auto text-balance leading-relaxed">
              Stratégie digitale, création premium et résultats mesurables pour transformer votre marque en leader du
              marché.
            </p>
          </div>

          <div
            className="flex flex-col sm:flex-row gap-4 justify-center pt-8 animate-woom"
            style={{ animationDelay: "0.2s" }}
          >
            <Button
              size="lg"
              className="bg-primary hover:bg-primary/90 text-primary-foreground text-base font-semibold px-8 py-6"
              onClick={() => setShowQuote(true)}
            >
              Demander un Devis
              <ArrowRight className="ml-3 h-5 w-5" />
            </Button>
            <Button
              size="lg"
              variant="outline"
              className="border-2 border-primary text-primary hover:bg-primary/5 bg-transparent text-base font-semibold px-8 py-6"
              onClick={scrollToServices}
            >
              Explorer les Services
            </Button>
          </div>
        </div>
      </div>

      {showQuote && <QuoteModal onClose={() => setShowQuote(false)} />}
    </section>
  )
}

function QuoteModal({ onClose }: { onClose: () => void }) {
  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 p-4">
      <div className="bg-card border border-primary/30 rounded-2xl max-w-md w-full p-8 animate-woom shadow-2xl shadow-primary/10">
        <h2 className="text-2xl font-bold mb-2">Demander un Devis</h2>
        <p className="text-muted-foreground text-sm mb-6">Décrivez votre projet et nous vous répondrons rapidement.</p>
        <form className="space-y-4">
          <div>
            <label className="block text-sm font-semibold mb-2">Nom</label>
            <input
              type="text"
              className="w-full bg-secondary/50 border border-border rounded-lg px-4 py-3 text-foreground placeholder-muted-foreground focus:outline-none focus:border-primary transition-colors"
              placeholder="Votre nom"
            />
          </div>
          <div>
            <label className="block text-sm font-semibold mb-2">Email</label>
            <input
              type="email"
              className="w-full bg-secondary/50 border border-border rounded-lg px-4 py-3 text-foreground placeholder-muted-foreground focus:outline-none focus:border-primary transition-colors"
              placeholder="votre@email.com"
            />
          </div>
          <div>
            <label className="block text-sm font-semibold mb-2">Entreprise</label>
            <input
              type="text"
              className="w-full bg-secondary/50 border border-border rounded-lg px-4 py-3 text-foreground placeholder-muted-foreground focus:outline-none focus:border-primary transition-colors"
              placeholder="Nom de l'entreprise"
            />
          </div>
          <div>
            <label className="block text-sm font-semibold mb-2">Description du projet</label>
            <textarea
              className="w-full bg-secondary/50 border border-border rounded-lg px-4 py-3 text-foreground placeholder-muted-foreground focus:outline-none focus:border-primary transition-colors"
              placeholder="Parlez-nous de votre projet"
              rows={4}
            />
          </div>
          <div className="flex gap-3 pt-4">
            <Button
              type="submit"
              className="flex-1 bg-primary hover:bg-primary/90 text-primary-foreground font-semibold"
            >
              Envoyer
            </Button>
            <Button
              type="button"
              variant="outline"
              className="flex-1 bg-transparent border-primary text-primary hover:bg-primary/5"
              onClick={onClose}
            >
              Annuler
            </Button>
          </div>
        </form>
      </div>
    </div>
  )
}
