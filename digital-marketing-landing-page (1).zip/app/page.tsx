"use client"

import { useState } from "react"
import { Hero } from "@/components/hero"
import { Services } from "@/components/services"
import { Portfolio } from "@/components/portfolio"
import { Quote } from "@/components/quote"
import { Footer } from "@/components/footer"
import { Intro } from "@/components/intro"
import { Header } from "@/components/header"
import { WhatsAppButton } from "@/components/whatsapp-button"

export default function Home() {
  const [showContent, setShowContent] = useState(false)

  if (!showContent) {
    return <Intro onEnter={() => setShowContent(true)} />
  }

  return (
    <main>
      <Header />
      <Hero />
      <Services />
      <Portfolio />
      <Quote />
      <Footer />
      <WhatsAppButton />
    </main>
  )
}
